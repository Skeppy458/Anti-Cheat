<?php

namespace AntiCheat;

use pocketmine\event\Listener;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\Item;
use pocketmine\level\Location;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements Listener{
  public function onEnable(){
    $this->getLogger()->info("Installing Anti Cheat");
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    $this->getLogger()->info("\n========================================================\n\n\n               Anti-Reach by Terminator\n               version 0.0.1\n\n\n========================================================");
  }
	public function onEntityDamageByEntity(EntityDamageEvent $event){
		$player = $event->getEntity();
		$cause = $event->getCause();
		switch($cause){
			case EntityDamageEvent::CAUSE_ENTITY_ATTACK:
			$damager = $event->getDamager();
			if(!$player instanceof Player) return;
			if(!$damager instanceof Player) return;
			if($damager->isCreative()) return;
			$damagerpos = $damager->getPosition() ?? new Vector3(0,0,0);
			$playerpos = $player->getPosition() ?? new Vector3(0,0,0);
			$distance = intval($damagerpos->distance($playerpos));
			$playerhealth = $player->getHealth();
			$playermaxhealth = $player->getMaxHealth();
      $damagerhealth = $damager->getHealth();
      $damagermaxhealth = $damager->getMaxhealth();
			$playername = $player->getDisplayName();
			$damagername = $damager->getDisplayName();
			$player->sendTip("§c".$damagername."§l§8| §a".$damagerhealth."§f/§b".$damagermaxhealth." §l§8| "."§r§bDistance: §7".$distance);
			$damager->sendTip("§e".$playername."§l§8| §a".$playerhealth."§f/§b".$playermaxhealth." §l§8| "."§r§bDistance: §7".$distance);
			$player->setNameTag("§b".$playername."\n§a".$playerhealth."§f/§b".$playermaxhealth." §l§8| "."§r§bDistance: §7".$distance);
			$damager->setNameTag("§b".$damagername."\n§a".$damagerhealth."§f/§b".$damagermaxhealth." §l§8| "."§r§bDistance: §7".$distance);
			if($distance > 5){
        $damager->sendMessage("§7[§eAnti Reach§7] §cReach Limit is 6 blocks");
			  $event->setCancelled();
            }
      if($distance > 7){
        $damager->kick("§§7[§eAnti Reach§7] §cReach Limit is 6 blocks");
        $player->sendMessage("§7[§eAnti Reach§7] §eYour Enemy got kicked by Anti Reach");
      }
		}
	}
}